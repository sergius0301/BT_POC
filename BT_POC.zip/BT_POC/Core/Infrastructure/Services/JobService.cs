﻿using Core.Infrastructure.Interfaces;
using Core.Infrastructure.Repository;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Infrastructure.Services
{
    public class JobService : IJobService
    {
        private BTRepository _efRepo;
        private StoredProceduresRepository _spRepo;
        public JobService(BTRepository efRepo, StoredProceduresRepository spRepo)
        {
            _efRepo = efRepo;
            _spRepo = spRepo;
        }
        public Task<List<Job>> GetJobs()
        {
            return _efRepo.GetAll();
        }

        public Task<List<Job>> GetJobsStoredProcedure()
        {
            return _spRepo.GetJobs();
        }

        public Task<List<Job>> GetJobsToExecute()
        {
            return _efRepo.SearchForJobs(x => x.TaskProcessed == false);
        }

        public Task<List<Job>> GetJobsToExecuteStoredProcedure()
        {
            return _spRepo.GetJobsToExecute();
        }

        public Task<Job> UpdateJob(Job job)
        {
            return _efRepo.Update(job);
        }
    }
}
