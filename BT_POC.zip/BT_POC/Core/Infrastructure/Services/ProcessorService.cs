﻿using Core.Infrastructure.Interfaces;
using System;
using System.Threading.Tasks;

namespace Core.Infrastructure.Services
{
    public class ProcessorService
    {
        private IJobService _service;
        private FileProcessorService _fileProcessor;

        public ProcessorService(IJobService service, FileProcessorService fileProcessor)
        {
            _service = service;
            _fileProcessor = fileProcessor;
        }
        public async Task<bool> ProcessAsync()
        {
            var jobsToExecute = await _service.GetJobsToExecute();

            foreach (var job in jobsToExecute)
            {
                if (IsFileProcessed(job.FilePath))
                {
                    UpdateJobStatus(job);
                }
            }
            return true;
        }

        private void UpdateJobStatus(Job job)
        {
            job.TaskProcessed = true;
            _service.UpdateJob(job);
        }
        private bool IsFileProcessed(string path)
        {
            var result = _fileProcessor.ReadFile(path);

            return !String.IsNullOrEmpty(result);
        }
    }
}
