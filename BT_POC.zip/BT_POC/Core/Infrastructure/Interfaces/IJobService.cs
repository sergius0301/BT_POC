﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Infrastructure.Interfaces
{
    public interface IJobService
    {
        Task<List<Job>> GetJobs();
        Task<List<Job>> GetJobsStoredProcedure();
        Task<List<Job>> GetJobsToExecute();
        Task<List<Job>> GetJobsToExecuteStoredProcedure();
        Task<Job> UpdateJob(Job job);

    }
}
