﻿using Microsoft.EntityFrameworkCore;

namespace Core.Infrastructure
{
    public partial class BancaTransilvaniaContext : DbContext
    {
        public BancaTransilvaniaContext()
        {
        }

        public BancaTransilvaniaContext(DbContextOptions<BancaTransilvaniaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Job> Jobs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Job>(entity =>
            {
                entity.HasKey(e => e.JobId)
                    .HasName("PK__Jobs__056690C2AE9FA730");

                entity.Property(e => e.TaskDate)
                    .HasColumnName("Task_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.TaskName)
                    .HasColumnName("Task_Name")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TaskProcessed).HasColumnName("Task_Processed");

                entity.Property(e => e.TaskType).HasColumnName("Task_Type");

                entity.Property(e => e.FilePath).HasColumnName("File_Path").HasMaxLength(255)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
