﻿using System;

namespace Core.Infrastructure
{
    public partial class Job : IEntity
    {
        public int JobId { get; set; }
        public bool? Tasked { get; set; }
        public string TaskName { get; set; }
        public DateTime? TaskDate { get; set; }
        public int? TaskType { get; set; }
        public bool? TaskProcessed { get; set; }
        public string FilePath { get; set; }
        int IEntity.Id { get => JobId; set { } }
    }
}
