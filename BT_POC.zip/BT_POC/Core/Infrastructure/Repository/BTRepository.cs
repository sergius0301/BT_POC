﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Core.Infrastructure.Repository
{
    public class BTRepository : EFRepository<Job, BancaTransilvaniaContext>
    {
        public BTRepository(BancaTransilvaniaContext context) : base(context)
        {

        }
        public async Task<List<Job>> SearchForJobs(Expression<Func<Job, bool>> predicate)
        {
            return await GetDbSet().Where(predicate).ToListAsync();
        }
    }
}

