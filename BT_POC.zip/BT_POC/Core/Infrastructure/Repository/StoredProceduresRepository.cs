﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Infrastructure.Repository
{
    public class StoredProceduresRepository
    {
        private BancaTransilvaniaContext _context;
        public StoredProceduresRepository(BancaTransilvaniaContext context)
        {
            _context = context;
        }
        public Task<List<Job>> GetJobs()
        {
            return _context.Jobs.FromSqlRaw("uspGetJOBS").ToListAsync();
        }
        public Task<List<Job>> GetJobsToExecute()
        {
            return _context.Jobs.FromSqlRaw("uspGetJOBSToExecute").ToListAsync();
        }
    }
}
