﻿namespace Core.Infrastructure
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
