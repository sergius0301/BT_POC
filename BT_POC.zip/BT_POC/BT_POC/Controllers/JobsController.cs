﻿using Core.Infrastructure;
using Core.Infrastructure.Interfaces;
using Core.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BT_POC.Controllers
{
    [ApiController]
    public class JobsController : ControllerBase
    {
        private IJobService _service;
        private ProcessorService _processorService;
        public JobsController(IJobService service, ProcessorService processorService)
        {
            _service = service;
            _processorService = processorService;
        }
        /// <summary>
        /// The enpoint to process all files that were not processed already
        /// </summary>
        /// <returns></returns>
        [Route("Processfiles")]
        [HttpGet]
        public async Task<bool> ProcessFiles()
        {
            return await _processorService.ProcessAsync();
        }

        [Route("GetJobs")]
        [HttpGet]
        public async Task<List<Job>> GetJobs()
        {
            return await _service.GetJobs();
        }
        [Route("GetJobsToExecute")]
        [HttpGet]
        public async Task<List<Job>> GetJobsToExecute()
        {
            return await _service.GetJobsToExecute();
        }
        [Route("GetJobsStoredprocedure")]
        [HttpGet]
        public async Task<List<Job>> GetJobsStoredprocedure()
        {
            return await _service.GetJobsStoredProcedure();
        }
        [Route("GetJobsToExecuteStoredProcedure")]
        [HttpGet]
        public async Task<List<Job>> GetJobsToExecuteStoredProcedure()
        {
            return await _service.GetJobsToExecuteStoredProcedure();
        }

    }
}