using Core.Infrastructure;
using Core.Infrastructure.Interfaces;
using Core.Infrastructure.Repository;
using Core.Infrastructure.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace BT_POC
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();
            services.AddDbContext<BancaTransilvaniaContext>(opt =>
               opt.UseSqlServer("Server=DESKTOP-6AD01ID;Database=BancaTransilvania;Trusted_Connection=True;"));
            services.AddScoped<BTRepository>();
            services.AddScoped<StoredProceduresRepository>();
            services.AddScoped<IJobService, JobService>();
            services.AddScoped<FileProcessorService>();
            services.AddScoped<ProcessorService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
